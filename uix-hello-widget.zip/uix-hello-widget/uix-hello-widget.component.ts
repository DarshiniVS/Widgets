import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uix-hello-widget',
  templateUrl: './uix-hello-widget.component.html',
  styleUrls: ['./uix-hello-widget.component.css']
})
export class UixHelloWidgetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
